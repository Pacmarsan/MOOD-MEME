
const express = require('express');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const cors = require('cors');
const path = require('path');

const { generateCaption } = require('./gptService');
const { searchVideo } = require('./videoSearch');
const { addCaptionToGif } = require('./overlayService');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());

app.use('/generated', express.static(path.join(__dirname)));

app.post('/api/generate-meme-video', async (req, res) => {
  const { user_mood, meme_tone } = req.body;

  if (!user_mood) return res.status(400).json({ error: 'Mood input required.' });

  try {
    const gptOutput = await generateCaption(user_mood, meme_tone || 'classic');
    const videoData = await searchVideo(gptOutput.template);
    const captionedGifPath = await addCaptionToGif(videoData.url, gptOutput.caption);

    res.status(200).json({
      template: gptOutput.template,
      caption: gptOutput.caption,
      video_url: `/generated/${path.basename(captionedGifPath)}`,
      source: videoData.source
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(PORT, () => {
  console.log(`MoodMeme backend running on http://localhost:${PORT}`);
});
